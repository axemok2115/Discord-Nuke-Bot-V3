# Discord-Nuke-Bot-V3
Discord Nuke Bot V3 By [ TheAxes ] Give Credit if You Use else: 🖕

# Features 🔥
1. -[x] Nuke
2. -[x] MassBan
3. -[x] MassKick
4. -[x] Nickall
5. -[x] MassDm
6. -[x] Webhookspam
7. -[x] stopwebhookspam
8. -[x] spam
9. -[x] DelChannel
10. -[x] delroles
11. -[x] Spamchannels
12. -[x] Spamroles
13. -[x] RenameServer
14. -[x] adminall
15. -[x] 24/7

## Extra
1. -[x] Help
2. -[x] serverinfo
3. -[x] Shutdown

### How To Use

```
git clone https://github.com/TheAxes/Discord-Nuke-Bot-V3.git
```

```
cd Discord-Nuke-Bot-V3
```

```
Validate config.json and put token in env
```

```
python main.py
```

YouTube Vedio -:
[![Youtube](https://cdn.discordapp.com/attachments/1055733614534471730/1070351462489673788/Thumbnail.jpg)](https://youtu.be/-TjVCjxIMiw)

## Credits -:
 youtube - https://youtube.com/@theaxes

 GitHub - https://GitHub.com/TheAxes

[![Run on Repl.it](https://repl.it/badge/github/replit/replbox)](https://replit.com/github/TheAxes/Discord-Nuke-Bot-V3)

<a href="https://www.buymeacoffee.com/AshOp" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>

